const CACHE="wedness-vector-v1";
self.addEventListener("install",e=>{self.skipWaiting()});
self.addEventListener("activate",e=>{e.waitUntil(self.clients.claim())});
self.addEventListener("fetch",e=>{if(e.request.method==="GET" && new URL(e.request.url).origin===location.origin){e.respondWith(caches.open(CACHE).then(async c=>(await c.match(e.request))||fetch(e.request).then(r=>{if(r.ok)c.put(e.request,r.clone());return r})))}});